// import { Loader } from "three";
import * as THREE from "/node_modules/three/build/three.module.js";
import { OrbitControls } from "/node_modules/three/examples/jsm/controls/OrbitControls.js";

const loader = new THREE.TextureLoader();
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(
  75,
  window.innerWidth / window.innerHeight,
  0.1,
  1000
);

camera.position.set(-2, 11, 20);
camera.lookAt(scene.position);
const color = 0xffffff;
const intensity = 0.6;
const light = new THREE.DirectionalLight(color, intensity);
light.position.set(-5, 4, 10);
// light.target.position.set(5, 0, 0);
scene.add(light);
// const alight = new THREE.AmbientLight(0x404040); // soft white light
// scene.add(alight);
// scene.add(light.target);
const renderer = new THREE.WebGLRenderer();
renderer.setSize(window.innerWidth, window.innerHeight);
document.body.appendChild(renderer.domElement);

const controls = new OrbitControls(camera, renderer.domElement);
controls.target.set(0, 0, 0);
controls.update();
const atmosphere_r = 10.2;
const atmospherewidthseg = 128;
const atmosphereheightseg = 128;
const atmosphere_geo = new THREE.SphereGeometry(
  atmosphere_r,
  atmospherewidthseg,
  atmosphereheightseg
);
const atmosphere_mat = new THREE.MeshPhysicalMaterial({
  emissive: 0x8cb9ff,
  transparent: true,
  side: THREE.BackSide,
  clearcoat: 1,
  opacity: 0.65,
});
const atmosphere = new THREE.Mesh(atmosphere_geo, atmosphere_mat);
scene.add(atmosphere);
atmosphere.position.set(0, 0, 0);
const globe_r = 10;
const globewidthseg = 128;
const globeheightseg = 128;
const globegeo = new THREE.SphereGeometry(
  globe_r,
  globewidthseg,
  globeheightseg
);
const globemat = new THREE.MeshPhongMaterial({
  map: loader.load("/Images/8081_earthmap4k.jpg"),
  bumpMap: loader.load("/Images/8081_earthbump4k.jpg"),
  bumpScale: 0.061,
  specularMap: loader.load("/Images/8081_earthspec4k.jpg"),
  specular: new THREE.Color("grey"),
});
const globe = new THREE.Mesh(globegeo, globemat);
scene.add(globe);

globe.position.set(0, 0, 0);
const clouds_r = 10.05;
const cloudswidthseg = 128;
const cloudsheightseg = 128;
const cloudsgeo = new THREE.SphereGeometry(
  clouds_r,
  cloudswidthseg,
  cloudsheightseg
);
const cloudsmat = new THREE.MeshPhongMaterial({
  map: loader.load("/Images/fair_clouds_4k.png"),
  transparent: true,
});
const clouds = new THREE.Mesh(cloudsgeo, cloudsmat);
scene.add(clouds);
clouds.position.set(0, 0, 0);
const clouds_r_1 = 10.005;
const cloudswidthseg_1 = 128;
const cloudsheightseg_1 = 128;
const cloudsgeo_1 = new THREE.SphereGeometry(
  clouds_r_1,
  cloudswidthseg_1,
  cloudsheightseg_1
);
const cloudsmat_1 = new THREE.MeshPhongMaterial({
  map: loader.load("/Images/fair_clouds_4k.png"),
  transparent: true,
});
const clouds_1 = new THREE.Mesh(cloudsgeo_1, cloudsmat_1);
scene.add(clouds_1);
clouds_1.position.set(0, 0, 0);
scene.add(clouds_1);
const clouds_r_2 = 10.1;
const cloudswidthseg_2 = 128;
const cloudsheightseg_2 = 128;
const cloudsgeo_2 = new THREE.SphereGeometry(
  clouds_r_2,
  cloudswidthseg_2,
  cloudsheightseg_2
);
const cloudsmat_2 = new THREE.MeshPhongMaterial({
  map: loader.load("/Images/fair_clouds_4k.png"),
  transparent: true,
});
const clouds_2 = new THREE.Mesh(cloudsgeo_2, cloudsmat_2);
scene.add(clouds_2);
clouds_2.position.set(0, 0, 0);
scene.add(clouds_2);
const clouds_r_3 = 10.009;
const cloudswidthseg_3 = 128;
const cloudsheightseg_3 = 128;
const cloudsgeo_3 = new THREE.SphereGeometry(
  clouds_r_3,
  cloudswidthseg_3,
  cloudsheightseg_3
);
const cloudsmat_3 = new THREE.MeshPhongMaterial({
  map: loader.load("/Images/fair_clouds_4k.png"),
  transparent: true,
});
const clouds_3 = new THREE.Mesh(cloudsgeo_3, cloudsmat_3);
scene.add(clouds_3);
clouds_3.position.set(0, 0, 0);
scene.add(clouds_3);
const clouds_r_4 = 10.019;
const cloudswidthseg_4 = 128;
const cloudsheightseg_4 = 128;
const cloudsgeo_4 = new THREE.SphereGeometry(
  clouds_r_4,
  cloudswidthseg_4,
  cloudsheightseg_4
);
const cloudsmat_4 = new THREE.MeshPhongMaterial({
  map: loader.load("/Images/fair_clouds_4k.png"),
  transparent: true,
});
const clouds_4 = new THREE.Mesh(cloudsgeo_4, cloudsmat_4);
scene.add(clouds_4);
clouds_4.position.set(0, 0, 0);
scene.add(clouds_4);
const universe_r = 1000;
const universewidthseg = 256;
const universeheightseg = 256;
const universe_geo = new THREE.SphereGeometry(
  universe_r,
  universewidthseg,
  universeheightseg
);
const universe_mat = new THREE.MeshBasicMaterial({
  map: loader.load("/Images/galaxy_starfield.png"),
  side: THREE.BackSide,
});

const universe = new THREE.Mesh(universe_geo, universe_mat);
scene.add(universe);
universe.position.set(0, 0, 0);
//globe.add(clouds);
// globe.add(atmosphere);
function globespin() {
  requestAnimationFrame(globespin);
  renderer.render(scene, camera);
  globe.rotation.y += 0.00001;
  clouds.rotation.y += Math.cos(0) * 10 ** -5;
  clouds_1.rotation.y += Math.cos(0) * 10 ** -4;
  clouds_2.rotation.y += Math.sin(1.57) * 10 ** -5;
  clouds_3.rotation.y += 0.00001;
}
globespin();
// function at() {
//   requestAnimationFrame(at);
//   renderer.render(scene, camera);
//   atmosphere.rotation.y += 0.0000000001;
// }
// at();
